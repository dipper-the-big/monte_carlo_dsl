// HeEmissionProcess.hpp

#ifndef GKMC_HeEmissionProcess_H
#define GKMC_HeEmissionProcess_H

#include <iostream>


namespace gkmc {
}

#endif // !GKMC_HeEmissionProcess_H
